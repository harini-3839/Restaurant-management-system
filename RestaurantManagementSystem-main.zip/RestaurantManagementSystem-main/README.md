# RestaurantManagementSystem
A Python-based restaurant management system with a secure login page. Built using Tkinter for the user interface and SQLite for database management, it offers features like order management and Billing.
